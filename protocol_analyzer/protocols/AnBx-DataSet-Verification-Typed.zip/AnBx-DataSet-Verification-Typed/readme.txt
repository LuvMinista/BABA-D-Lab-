This dataset contains:
- AnBx protocols in the AnBx folder
- Verification results for each single goal with OFMC and ProVerif

Results files:
- results-single-anb-typed-sessions_1-depth_0-2022-PCM.csv - Verification with OFMC 2022 - 1 session (typed)
- results-single-anb-typed-sessions_2-depth_0-2022-PCM.csv - Verification with OFMC 2022 - 2 sessions (typed)
- results-single-pv-typed-205-PCM.csv - Verification with Proverif 2.05 - unlimited sessions (typed)

Note: The AnBx protocol files are stored in the AnBx subfolder
